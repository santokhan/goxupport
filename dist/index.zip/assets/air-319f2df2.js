const a="/assets/air-3c4dedfa.jpg";export{a};

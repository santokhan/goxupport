const e="/assets/electrical-1f68b408.jpg";export{e};

const s="/assets/wifi-da0429e6.jpg";export{s as w};

const c="/assets/cleaning-3e93cd52.jpg";export{c};

const p="/assets/plumbing-add79ee2.jpg";export{p};

const p="/assets/paint-057ddd53.jpg";export{p};

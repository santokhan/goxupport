const s="/assets/it-74cd96cf.jpg";export{s as i};

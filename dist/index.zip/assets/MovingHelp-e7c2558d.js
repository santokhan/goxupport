import{_ as e}from"./_plugin-vue_export-helper-c27b6911.js";import{o,c}from"./index-ccaff5eb.js";const r={};function t(n,s){return o(),c("div")}const f=e(r,[["render",t]]);export{f as default};

const p="/assets/plumbing-a56dad3e.jpg";export{p};

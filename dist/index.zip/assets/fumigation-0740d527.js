const a="/assets/fumigation-edae40e3.jpg";export{a as f};
